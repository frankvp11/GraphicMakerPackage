
from nicegui.element import Element


class AlphaMask(Element, component="alphamask.js"):
    def __init__(self) -> None:
        super().__init__()
        