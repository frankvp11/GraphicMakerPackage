from nicegui.element import Element

class Clip(Element, component="clip.js"):
    def __init__(self) -> None:
        super().__init__()
