

from nicegui.element import Element


class SVG(Element, component="svg.js"):
    def __init__(self) -> None:
        super().__init__()
        
        

