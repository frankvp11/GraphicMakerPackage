
This project creates simple svg graphics
